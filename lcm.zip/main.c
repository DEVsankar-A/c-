/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a,b,max;
    printf("enter the 1st number");
    scanf("%d",&a);
        printf("enter the 2nd number");
    scanf("%d",&b);
    
    if(a=b){
        printf("lcm=%d",a);
        return 0;
    }
    else if(a>b){
        max=a;
    }else{
        max=b;
    }
    while(1){
        if((max%a==0) && (max%b==0)){
            printf("lcm=%d",max);
            return 0;
        }
        max++;
    }
    
    return 0;
}
