/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a;
    printf("enter the year");
    scanf("%d",&a);
    if(a%4==0&&a%100!=0||a%400==0){
        printf("%d is a leap year",a);
    }
  
    
    else{printf("%d is not leap year",a);
        
    }

    return 0;
}
