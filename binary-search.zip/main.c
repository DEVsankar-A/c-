/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
 int n,a,mid;
  
    printf("enter the no of elements: ");
    scanf("%d",&n);
    
    int left=0;
    int right=n-1;
    
    int arr[n];
    for(int i=0;i<n;i++){
        scanf("%d",&arr[i]);
    }
    
    printf("enter the element to search: ");
    scanf("%d",&a);
  
    while(left<=right){
        mid=(left+right)/2;
        
        if(arr[mid]==a){
            printf("the %d is found",a);
            break;
        }
        else if(arr[mid]>a){
            right=mid-1;
        }
            
        else{
            left=mid+1;
        }
    }
    
      
    if(left>right){
        printf("element not found");
    }
      
    
    

    return 0;
}