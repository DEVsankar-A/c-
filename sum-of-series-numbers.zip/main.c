/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int sum(int i,int a)
{
    int n=0;
    for(i;i<=a;i++)
    {
     n=n+i;
    }

    return n;
}
int main()
{
    int i,a;
    printf("enter the number");
    scanf("%d",&i);
    printf("enter the last number");
    scanf("%d",&a);
    printf("%d", sum(i,a));
}