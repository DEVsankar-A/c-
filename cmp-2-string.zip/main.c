/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>

int main()
{
    // char str1[50]="dev";
    // char str2[50]="dev";
    // int a;
    
    // strcat(str1,str2);
    // printf("%s\n",str1);
    
    // a = strcmp(str1,str2);
    // printf("%d",a);
    
    char f[50] = "dev";
    char s[50] = "dev";
    
    int a = strcmp(f,s);
    printf("%d",a);
    
    return 0;
}