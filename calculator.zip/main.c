/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a,b,op;
    printf("enter the 1st number");
    scanf("%d",&a);
       printf("enter the 2nd number");
    scanf("%d",&b);
    printf("\n 1 sum\n 2 sub\n 3 multi\n 4 div\n");
    printf("    enter the operands");
    scanf("%d",&op);
    
    switch(op){
        case 1:printf("%d",a+b);
        break;
        case 2:printf("%d",a-b);
        break;
        case 3:printf("%d",a*b);
        break;
        case 4:printf("%d",a/b);
        break;
        default :printf("you enter a false choice");
    }
    return 0;
}
