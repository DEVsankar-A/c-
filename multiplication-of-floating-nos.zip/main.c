int main()
{
    float a,b;
    printf("enter the 1st number");
    scanf("%f",&a);
       printf("enter the 2nd number");
    scanf("%f",&b);

    printf("%f",a*b);
    
    return 0;
    
}    
