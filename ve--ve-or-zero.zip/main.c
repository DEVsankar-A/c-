/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int A;
    printf("enter the no");
    scanf("%d",&A);
    
    if(A<0){
        printf("the %d no is -ve",A);
    }
    else if(A>0){
        printf("the %d no is +ve",A);
    }
    else{
        printf("the  %d no is zero",A);
    }
    
    return 0;
}